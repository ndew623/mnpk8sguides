# DC/OS to K8s guide

1. dcos-service-in-k8s.md
2. k8s-resources.md
3. jobs.md
4. declarativness.md
5. namespaces.md